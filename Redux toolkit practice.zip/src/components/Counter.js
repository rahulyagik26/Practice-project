import { useSelector, useDispatch } from "react-redux";

import { counterActions } from "../store";
import classes from './Counter.module.css';

const Counter = () => {
  const dispatch = useDispatch()
  const counter = useSelector(state => state.counter.counter)
  const show = useSelector(state => state.counter.showCounter)

  // Using Redux Toolkit ============================
  const incrementHandler = () => {
    dispatch(counterActions.increment())
  }

  const decrementHandler = () => {
    dispatch(counterActions.decrement());
  }

  const increaseHandler = () => {
    dispatch(counterActions.increase(5));
  }

  const toggleCounterHandler = () => {
    dispatch(counterActions.toggle());
  };

  // Using Redux =========================
  // const incrementHandler = () => {
  //   dispatch({ type: "increment" })
  // }

  // const decrementHandler = () => {
  //   dispatch({ type: "decrement" });
  // }

  // const increaseHandler = () => {
  //   dispatch({ type: "increase", amount: 5 });
  // }

  // const toggleCounterHandler = () => {
  //   dispatch({ type: "toggle" });
  // };

  return (
    <main className={classes.counter}>
      <h1>Redux Counter</h1>
      {show && <div className={classes.value}>{counter}</div>}

      <button onClick={toggleCounterHandler}>Toggle Counter</button>
      <button onClick={increaseHandler}>Increase by 5</button>
      <button onClick={incrementHandler}>Increment</button>
      <button onClick={decrementHandler}>Decrement</button>
    </main>
  );
};

export default Counter;
