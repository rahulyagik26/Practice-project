import React from 'react';
import "../index.css";

const NotFound = () => {
    return (
        <p className="centered">Page Not Found</p>
    )
}

export default NotFound
